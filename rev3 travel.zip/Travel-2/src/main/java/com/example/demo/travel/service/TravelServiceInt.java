package com.example.demo.travel.service;

import java.util.List;

import com.example.demo.travel.entity.TravelEntity;



public interface TravelServiceInt {
	public List<TravelEntity> gettData();
	public void savetData(TravelEntity te);
	public void updatetData(TravelEntity te);
	public void deletetData(int id);
}
