package com.example.demo.travel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.travel.entity.SignupEntity;
import com.example.demo.travel.service.SignupService;





@RestController
public class SignupController {

	@Autowired
	private SignupService ss;
	
	@GetMapping("/getsignup")
	public List<SignupEntity> getDetails(){
		return ss.getsData();
	}
	
	@PostMapping("/savesignup")
	public void savedetails(@RequestBody SignupEntity se) {
		ss.saveData(se);
	}
	
	@PutMapping("/updatesignup")
	public void updateDetails(@RequestBody SignupEntity se,@RequestParam int id) {
		se.setId(id);
		ss.updateData(se);
	}
	
	@DeleteMapping("/deletesignup")
	public void deleteDetails(@RequestParam int id) {
		ss.deleteData(id);
	}
}
