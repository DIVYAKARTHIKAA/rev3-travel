package com.example.demo.travel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.travel.entity.SignupEntity;

import com.example.demo.travel.repo.SignupRepoInt;

@Service
public class SignupService implements SignupServiceInt {

	@Autowired
	private SignupRepoInt sr;
	@Override
	public List<SignupEntity> getsData() {
		return sr.findAll();
	}

	@Override
	public void saveData(SignupEntity se) {
		sr.save(se);

	}

	@Override
	public void updateData(SignupEntity se) {
		sr.save(se);

	}

	@Override
	public void deleteData(int id) {
		sr.deleteById(id);

	}

}
