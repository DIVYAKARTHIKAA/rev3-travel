package com.example.demo.travel.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="travel")

public class TravelEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Column(name="name")
	private String name;
	@Column(name="source")
	private String source;
	@Column(name="destination")
	private String destination;
	@Column(name="modeoftransportation")
	private String modeoftransportation;
	@Column(name="cost")
	private int cost;
	public TravelEntity() {
		super();
	}
	public TravelEntity(int id, String name, String source, String destination, String modeoftransportation, int cost) {
		super();
		this.id = id;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.modeoftransportation = modeoftransportation;
		this.cost = cost;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getModeoftransportation() {
		return modeoftransportation;
	}
	public void setModeoftransportation(String modeoftransportation) {
		this.modeoftransportation = modeoftransportation;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	

}
