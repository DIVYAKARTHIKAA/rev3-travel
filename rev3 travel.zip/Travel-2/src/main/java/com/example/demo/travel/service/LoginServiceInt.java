package com.example.demo.travel.service;

import java.util.List;

import com.example.demo.travel.entity.LoginEntity;



public interface LoginServiceInt {
	public List<LoginEntity> getlData();
	public void savelData(LoginEntity le);
	public void updatelData(LoginEntity le);
	public void deletelData(int id);
}
