package com.example.demo.travel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.travel.entity.TravelEntity;
import com.example.demo.travel.service.TravelService;



@RestController
public class TravelController {

	@Autowired
	private TravelService ts;
	
	@GetMapping("/getdata")
	public List<TravelEntity> getDetails(){
		return ts.gettData();
	}
	
	@PostMapping("/savedata")
	public void savedetails(@RequestBody TravelEntity te) {
		ts.savetData(te);
	}
	
	@PutMapping("/updatedata")
	public void updateDetails(@RequestBody TravelEntity te,@RequestParam int id) {
		te.setId(id);
		ts.updatetData(te);
	}
	
	@DeleteMapping("/deletedata")
	public void deleteDetails(@RequestParam int id) {
		ts.deletetData(id);
	}
}
