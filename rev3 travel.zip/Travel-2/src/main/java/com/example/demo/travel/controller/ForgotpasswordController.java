package com.example.demo.travel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.travel.entity.ForgotpasswordEntity;
import com.example.demo.travel.service.ForgotpasswordService;


@RestController
public class ForgotpasswordController {

	@Autowired
	private ForgotpasswordService fs;
	
	@GetMapping("/getforpass")
	public List<ForgotpasswordEntity> getDetails(){
		return fs.getfData();
	}
	
	@PostMapping("/saveforpass")
	public void savedetails(@RequestBody ForgotpasswordEntity fe) {
		fs.savefData(fe);
	}
	
	@PutMapping("/updateforpass")
	public void updateDetails(@RequestBody ForgotpasswordEntity fe,@RequestParam int id) {
		fe.setId(id);
		fs.updatefData(fe);
	}
	
	@DeleteMapping("/deleteforpass")
	public void deleteDetails(@RequestParam int id) {
		fs.deletefData(id);
	}
}
