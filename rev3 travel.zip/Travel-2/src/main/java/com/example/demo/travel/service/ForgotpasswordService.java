package com.example.demo.travel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.travel.entity.ForgotpasswordEntity;
import com.example.demo.travel.repo.ForgotpasswordRepoInt;

@Service
public class ForgotpasswordService implements ForgotpasswordServiceInt {

	@Autowired
	private ForgotpasswordRepoInt fr;
	@Override
	public List<ForgotpasswordEntity> getfData() {
		return fr.findAll();
	}

	@Override
	public void savefData(ForgotpasswordEntity fe) {
		fr.save(fe);

	}

	@Override
	public void updatefData(ForgotpasswordEntity fe) {
		fr.save(fe);

	}

	@Override
	public void deletefData(int id) {
		fr.deleteById(id);

	}

}
