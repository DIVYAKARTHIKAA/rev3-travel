package com.example.demo.travel.service;

import java.util.List;

import com.example.demo.travel.entity.ForgotpasswordEntity;



public interface ForgotpasswordServiceInt {

	public List<ForgotpasswordEntity> getfData();
	public void savefData(ForgotpasswordEntity fe);
	public void updatefData(ForgotpasswordEntity fe);
	public void deletefData(int id);
}
