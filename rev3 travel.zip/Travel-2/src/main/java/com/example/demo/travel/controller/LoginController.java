package com.example.demo.travel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.travel.entity.LoginEntity;
import com.example.demo.travel.service.LoginService;




@RestController
public class LoginController {

	@Autowired
	private LoginService ls;
	
	@GetMapping("/getlogin")
	public List<LoginEntity> getDetails(){
		return ls.getlData();
	}
	
	@PostMapping("/savelogin")
	public void savedetails(@RequestBody LoginEntity le) {
		ls.savelData(le);
	}
	
	@PutMapping("/updatelogin")
	public void updateDetails(@RequestBody LoginEntity le,@RequestParam int id) {
		le.setId(id);
		ls.updatelData(le);
	}
	
	@DeleteMapping("/deletelogin")
	public void deleteDetails(@RequestParam int id) {
		ls.deletelData(id);
	}
}
