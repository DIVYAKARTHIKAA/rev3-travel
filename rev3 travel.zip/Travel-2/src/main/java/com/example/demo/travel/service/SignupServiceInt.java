package com.example.demo.travel.service;

import java.util.List;

import com.example.demo.travel.entity.SignupEntity;



public interface SignupServiceInt {
	public List<SignupEntity> getsData();
	public void saveData(SignupEntity se);
	public void updateData(SignupEntity se);
	public void deleteData(int id);
}
