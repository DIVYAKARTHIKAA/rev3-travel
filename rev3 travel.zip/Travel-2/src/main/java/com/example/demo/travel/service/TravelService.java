package com.example.demo.travel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.travel.entity.TravelEntity;
import com.example.demo.travel.repo.TravelRepoInt;

@Service
public class TravelService implements TravelServiceInt {

	@Autowired
	private TravelRepoInt tr;
	
	@Override
	public List<TravelEntity> gettData() {
		return tr.findAll();
	}

	@Override
	public void savetData(TravelEntity te) {
		tr.save(te);

	}

	@Override
	public void updatetData(TravelEntity te) {
		tr.save(te);

	}

	@Override
	public void deletetData(int id) {
		tr.deleteById(id);

	}

}
