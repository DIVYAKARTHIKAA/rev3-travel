package com.example.demo.travel.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.travel.entity.TravelEntity;


@Repository
public interface TravelRepoInt extends JpaRepository<TravelEntity, Integer> {

}
