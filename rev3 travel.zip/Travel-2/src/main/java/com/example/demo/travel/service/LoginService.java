package com.example.demo.travel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.travel.entity.LoginEntity;
import com.example.demo.travel.repo.LoginRepoInt;

@Service
public class LoginService implements LoginServiceInt {

	@Autowired
	private LoginRepoInt lr;
	@Override
	public List<LoginEntity> getlData() {
		
		return lr.findAll();
	}

	@Override
	public void savelData(LoginEntity le) {
		lr.save(le);

	}

	@Override
	public void updatelData(LoginEntity le) {
		lr.save(le);

	}

	@Override
	public void deletelData(int id) {
		lr.deleteById(id);

	}

}
